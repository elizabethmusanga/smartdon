<?php
//php sample code


  $postData = array(
                    'action' => 'compose',
                    'username' => 'reuby',
                    'api_key' => '2ch1TJtStzaE4xm6hu44grQsPxjTOiOFtBZ2iDPxgBNFPzOCBX',
                    'sender' => 'SMARTLINK',
                    'to' => '254735222746',
                    'message' => 'Hello',
                    'msgtype' => '5',
                    'dlr' => '0',
                );


                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => "https://www.sms.movesms.co.ke/API/",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $postData

                ));

                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

                $output = curl_exec($ch);

                if (curl_errno($ch)) {
                    // echo 'error:' . curl_error($ch);
                    $output = curl_error($ch);
                }

                curl_close($ch);
            
?>