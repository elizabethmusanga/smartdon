<?php
//php sample code

$username='reuby';
$key='2ch1TJtStzaE4xm6hu44grQsPxjTOiOFtBZ2iDPxgBNFPzOCBX';
$senderid='SMARTLINK';
$phonenumber='254740147010';
$message=urlencode('hello');
$live_url ='https://sms.movesms.co.ke/api/compose?username='.$username.'&api_key='.$key.'&sender='.$senderid.'&to='.$phonenumber.'&message='.$message.'&msgtype=5&dlr=0';
$parse_url=file($live_url);
$output1=  $parse_url[0];
echo $output1;


?>